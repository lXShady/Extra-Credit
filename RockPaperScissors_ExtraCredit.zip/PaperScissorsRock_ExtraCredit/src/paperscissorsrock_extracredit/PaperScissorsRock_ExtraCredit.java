/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package paperscissorsrock_extracredit;

import java.io.File;
import javafx.scene.control.Label;
import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;

/**
 *
 * @author Brandon
 */
public class PaperScissorsRock_ExtraCredit extends Application {

     
    public static void main(String[] args) {
        Application.launch(args);
        
    }
    
    private int playerItem;
    private int computerItem;
    
    
    public void setPlayer(int choice) {
        switch (choice) {
            case 0:
                this.playerItem = 0;
                break;
            case 1:
                this.playerItem = 1;
                break;
            default:
                this.playerItem = 2;
                break;
        }
    }
    
    public String battle(int player, int computer) {
        //rock = 0, paper = 1, scissors = 2
       if(player == computer) {
           return "It was a tie!";
       }
       else if(player == 0 && computer == 1) {
           return "Computer wins!";
       }
       else if(player == 0 && computer == 2) {
           return "Player wins!";
       }
       else if(player == 1 && computer == 0) {
           return "Player wins!";
       }
       else if (player == 1 && computer == 2) {
           return "Computer wins!";
       }
       else if(player == 2 && computer == 0) {
           return "Computer wins!";
       }
       else if (player == 2 && computer == 1) {
           return "Player wins!";
       }
       else {
           return "Something went wrong!";
       }
       
    }
    
    public String setComputer() {
        computerItem = (int) (Math.random() * 3);

            if(computerItem == 0) {
                return "rock.png";
            }
            else if(computerItem == 1) {
                return "paper.png";
            }
            else if(computerItem == 2) {
                return "scissors.png";
            }
            else {
                return "Something went wrong!";
            }
    }

    @Override
    public void start(Stage primaryStage) throws Exception {
        GridPane mainPane = new GridPane();
        mainPane.setPrefHeight(800);
        mainPane.setPrefWidth(400);
        mainPane.setHgap(15);
        mainPane.setVgap(15);
        
        Button b1 = new Button();
        b1.setGraphic(new ImageView(new Image(new File("rock.png").toURI().toString())));
        
        Button b2 = new Button();
        b2.setGraphic(new ImageView(new Image(new File("paper.png").toURI().toString())));
        
        Button b3 = new Button();
        b3.setGraphic(new ImageView(new Image(new File("scissors.png").toURI().toString())));
        
        Label lbCompChoice = new Label();
        Label lbResult = new Label();
        
        Label lbChoose = new Label("Choose your weapon!");
        Label lbCompChoose = new Label("Computer chooses!");
        
        //0 = rock, 1 = paper, 2 = scissors
        b1.setOnAction((e) -> {
            setPlayer(0);
            lbCompChoice.setGraphic(new ImageView(new Image(new File(setComputer()).toURI().toString())));
            lbResult.setText(battle(playerItem, computerItem));
        });
        
        b2.setOnAction((e) -> {
           setPlayer(1); 
           lbCompChoice.setGraphic(new ImageView(new Image(new File(setComputer()).toURI().toString())));
           lbResult.setText(battle(playerItem, computerItem));
        });
        
        b3.setOnAction((e) -> {
           setPlayer(2);
           lbCompChoice.setGraphic(new ImageView(new Image(new File(setComputer()).toURI().toString())));
           lbResult.setText(battle(playerItem, computerItem));
        });
         
        mainPane.add(lbChoose, 0, 0);
        mainPane.add(b1, 0, 1);
        mainPane.add(b2, 1, 1);
        mainPane.add(b3, 2, 1);
        mainPane.add(lbCompChoose, 0, 2);
        mainPane.add(lbCompChoice, 0, 3);
        mainPane.add(lbResult, 0, 4);
        
        Scene scene = new Scene(mainPane);
        primaryStage.setScene(scene);
        primaryStage.show();
        
        
    }
    
}
